from odoo import models

class DriverXlsx(models.AbstractModel):
    _name = 'report.driver_roaster.report_driver_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, lines):
            # print('lines', lines)

            format1 = (workbook.add_format({'font_size': 14, 'align': 'vcentre', 'bold': True}))
            format2 = (workbook.add_format({'font_size': 10, 'align': 'vcentre', 'bold': True}))
            format3 = (workbook.add_format({'font_size': 8, 'align': 'vcentre', 'bold': True}))
            # One sheet by partner
            sheet = workbook.add_worksheet('driver Report')
            sheet.write(0, 1, 'NAME:', format1)
            # for data in lines:
            sheet.write(0, 2, lines.employee_id.name, format2)
            # bold = workbook.add_format({'bold': True})
            # sheet.write(0, 0, obj.name, bold)
            row = 1
            col = 1
            days = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat']
            sheet.write(row, col, 'Date', format1)
            sheet.write(row, col+1, 'Day', format1)
            sheet.write(row, col+2, 'Hour', format1)
            data = self.env['driver.schedule.lines'].search([])
            for val in data:
                print("VAl --->>>", val)
                print("VAl date_schedule --->>>", val.date_schedule)
                print("VAl day_schedule --->>>", days[int(val.day_schedule)])
                print("VAl hours_schedule --->>>", val.hours_schedule)

                sheet.write(row+1, col, str(val.date_schedule), format3)
                sheet.write(row+1, col+1, days[int(val.day_schedule)], format2)
                sheet.write(row+1, col+2, val.hours_schedule, format2)
                row += 1


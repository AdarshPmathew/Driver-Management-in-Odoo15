from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from num2words import num2words
from calendar import monthrange
import datetime
import json


class DriverRegistration(models.Model):
    _name = "driver.registration"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = ('employee_id')

    employee_id = fields.Many2one('hr.employee', string="Name", required=True)
    date = fields.Datetime(string="Date")
    driver_registration_line_ids = fields.One2many('driver.registration.lines', 'roaster_id')
    department = fields.Many2one('hr.department', string="Department")
    tag_ids = fields.Many2many("driver.tags", string="Tags")
    email = fields.Char(related="employee_id.work_email", string="Email")
    company_id = fields.Many2one('res.company', required=True, readonly=True, default=lambda self: self.env.company)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('in progress', 'In Progress'),
        ('assign', 'Assign'),
        ('cancel', 'Cancel')], string="Status", )

    def action_assign(self):
        # print('hh')
        # for rec in self:
        #     rec.state = 'assign'
        self.state = 'assign'

    def open_driver_schedule_wizard(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'driver.schedule.wizard',
            'view_mode': 'form',
            'views': [(False, 'form')],
            'target': 'new',
            'context': {'default_driver_ids': self.id}
        }

    def action_send_email(self):
        template_id = self.env.ref('driver_roaster.email_to_driver')
        mail_values = {
            'email_from': 'adarshmathew6232@gmail.com',
            'email_to': self.employee_id.work_email,
            'subject': 'TEST',
            'state': 'outgoing',
            'is_notification': True,
            'auto_delete': True,
        }
        mail = self.env['mail.mail'].create(mail_values)
        mail.send()
        print(template_id)
        for rec in self:
            template_id.send_mail(rec.id)

        body_html = "Email Recieved"

        odoobot_id = self.env.ref('base.partner_root').id
        channel = self.env['mail.channel'].sudo().search(
            [('name', '=', 'Notification'), ('channel_partner_ids', 'in', [self.employee_id.address_home_id.id])],
            limit=1)

        print("")
        if not channel:
            channel = self.env['mail.channel'].with_context(
                mail_create_nosubscribe=True).sudo().create({
                'channel_partner_ids': [(4, self.employee_id.address_home_id.id), (4, odoobot_id)],
                'public': 'private',
                'channel_type': 'channel',
                'name': f'Notification',
                'display_name': f'Notification'
            })

        channel.sudo().message_post(
            body=body_html,
            author_id=odoobot_id,
            message_type="comment",
            subtype_xmlid="mail.mt_comment",
        )

    def action_open_driver_schedule(self):
        schedule = self.env['driver.schedule'].sudo().search([('driver_s', '=', self.id)], limit=1)
        print("schedule --->>>", schedule)
        return {
            'type': 'ir.actions.act_window',
            'name': 'schedule',
            'res_model': 'driver.schedule',
            'view_mode': 'form',
            'target': 'current',
            'res_id': schedule.id,
            'views': [(False, 'form')],
        }


class DriverHostLines(models.Model):
    _name = "driver.registration.lines"
    _description = "Driver Lines"

    roaster_id = fields.Many2one('driver.registration', string="Roaster Id")
    sale_order_id = fields.Many2one('sale.order', string="Sale Order")
    amount = fields.Float(string="Amount")
    date_r = fields.Datetime(string="Date", related="sale_order_id.date_order")
    name = fields.Char(string="Name", related="sale_order_id.name")
    partner_id = fields.Many2one(string="Customer", related="sale_order_id.partner_id")

    @api.onchange('sale_order_id')
    def onchange_sale_order_id(self):
        if self.roaster_id.date:
            return {'domain': {'sale_order_id': [('date_order', '=', self.roaster_id.date)]}}
        else:
            raise ValidationError(_("fill the date field!!"))
        # for rec in self:
        #     return {'domain': {'date': [('date_order', '=', rec.roaster_id.id)]}}


class DriverTags(models.Model):
    _name = "driver.tags"
    _description = "Driver tags"
    _rec_name = 'tags'

    tags = fields.Char(string="Tags")
    color = fields.Integer(string="color")


class DriverSchedule(models.Model):
    _name = "driver.schedule"
    _description = "Driver Schedule"

    driver_s = fields.Many2one('driver.registration', string="Driver")
    year_s = fields.Char(string='Year')
    month_s = fields.Selection([('1', 'January'), ('2', 'February'), ('3', 'March'), ('4', 'April'), ('5', 'May'),
                                ('6', 'June'), ('7', 'July'), ('8', 'August'), ('9', 'September'), ('10', 'October'),
                                ('11', 'November'),
                                ('12', 'December')], string='Month')
    driver_scheduling_line_ids = fields.One2many('driver.schedule.lines', 'roaster_id', readonly=False)

    def onchange_year_month(self):
        driver_schedule_data = self.env['driver.schedule.lines'].sudo().search([('roaster_id', '=', self.id)])
        for rec in driver_schedule_data:
            rec.sudo().unlink()
        if self.driver_s:
            if self.month_s and self.year_s:
                # print(self.month_s)
                nb_days = monthrange(int(self.year_s), int(self.month_s))[1]
                # date_dict = {}
                date_list = []
                days_list = []
                if self.driver_s.employee_id.holiday_line_ids:
                    for day in self.driver_s.employee_id.holiday_line_ids:
                        days_list.append(day.day_schedule)
                        # print(day.day_schedule)
                date = [datetime.date(int(self.year_s), int(self.month_s), day) for day in range(1, nb_days + 1)]
                for i in date:
                    # print(i.weekday())
                    if str(i.weekday()) not in days_list:
                        # print(i.weekday())
                        date_dict = {
                            'date_schedule': i,
                            'day_schedule': str(i.weekday())
                        }

                        date_list.append(date_dict)
                self.driver_scheduling_line_ids = [(0, 0, ids) for ids in date_list]

    # def print_pdf(self):
    #
    #     driver_schedule_data = self.env['driver.schedule.lines'].sudo().search([('employee_id', '=', self.names.id)])
    # def driver_report(self):
    # data = {
    #     'model_id': self.id,
    #     'name': self.driver_s,
    # }
    # return {
    #     'type': 'ir.actions.report',
    #     'data': {
    #         'model': 'driver.schedule',
    #         'options': data,
    #         # 'options': json.dumps(data,default=data_utils.json_default()),
    #         'output_format': 'xlsx',
    #         'report_name': 'driver report',
    #         'report_format': 'xlsx',
    #
    #     }
    #
    # }


class DriverScheduleInherit(models.Model):
    _name = "driver.schedule.lines"
    _description = "Driver Schedule Line"

    roaster_id = fields.Many2one('driver.schedule', string="Roaster Id")
    date_schedule = fields.Date(string="Date")
    day_schedule = fields.Selection(
        [('0', 'Sunday'), ('1', 'Monday'), ('2', 'Tuesday'), ('3', 'Wednesday'), ('4', 'Thursday'), ('5', 'Friday'),
         ('6', 'Saturday')],
        string="Day")
    hours_schedule = fields.Float(string="Working Hours", default=8.00)
    employee_id = fields.Many2one('hr.employee', related='roaster_id.driver_s.employee_id')

    @api.onchange('hours_schedule')
    def onchange_hours_schedule(self):
        self.hours_schedule = '8.00'


class HrEmployee(models.Model):
    _inherit = 'hr.employee'
    holiday_line_ids = fields.One2many("driver.holidays.lines", 'employee_id')

    @api.constrains('holiday_line_ids')
    def constrains_holiday_line_ids(self):
        day_list = []
        for days in self.holiday_line_ids:
            if days.day_schedule in day_list:
                raise ValidationError("Day already exists!")
            else:
                day_list.append(days.day_schedule)

    # @api.constrains('holiday_line_ids')
    # def _constrains_line_ids(self):
    #     day_list = []
    #     for line in self.holiday_line_ids:
    #         if line.day_schedule in day_list:
    #             raise ValidationError("Day already exists!")
    #         else:
    #             day_list.append(line.day_schedule)

    # _sql_constraints = [
    #     ('unique_day_schedule', 'unique(holiday_line_ids.employee_id,holiday_line_ids.day_schedule)', 'Day already exists!')
    # ]


class DriverHolidays(models.Model):
    _name = "driver.holidays.lines"
    _description = "Driver Holidays Lines"

    employee_id = fields.Many2one("hr.employee", string='Employee')
    day_schedule = fields.Selection(
        [('0', 'Sunday'), ('1', 'Monday'), ('2', 'Tuesday'), ('3', 'Wednesday'), ('4', 'Thursday'), ('5', 'Friday'),
         ('6', 'Saturday')],
        string="Day")

    # @api.constrains('day_schedule')
    # def constrains_day_schedule(self):
    #     same_day = []
    #     for i in self.employee_id.holiday_line_ids:
    #         same_day.append(i.day_schedule)
    #     print(same_day)

    # @api.onchange('day_schedule')
    # def onchange_day_schedule(self):
    #     same_day = []
    #     for i in self.employee_id.holiday_line_ids:
    #         same_day.append(i.day_schedule)
    #     print(same_day)
    #     for same in same_day:
    #         if self.day_schedule == same:
    #     # if self.day_schedule in same_day:
    #             raise ValidationError(_("Day already exists!"))

class AccountMoveInherited(models.Model):
    _inherit = 'account.move'
    amount_in_words = fields.Char(string="Words", compute="compute_amount_to_text")
    contract = fields.Char(string="Contract No")
    reference = fields.Char(string="Reference")


    @api.depends('amount_in_words')
    def compute_amount_to_text(self):
        for rec in self:
            pre = float(rec.amount_total)
            text = ''
            entire_num = int((str(pre).split('.'))[0])
            decimal_num = int((str(pre).split('.'))[1])
            if decimal_num < 10:
                decimal_num = decimal_num * 10
            text += num2words(entire_num, lang='en')
            text += ' con '
            text += num2words(decimal_num, lang='en')
            rec.amount_in_words = text



class StockMoveLineInterit(models.Model):
    _inherit = 'stock.move.line'

    contract = fields.Char(string="Contract No")
    reference = fields.Char(string="Reference")

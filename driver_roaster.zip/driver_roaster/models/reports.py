from odoo import api, fields, models, _
from odoo import tools
from odoo.exceptions import ValidationError
from calendar import monthrange
import datetime


class DriverReport(models.Model):
    _name = "driver.analysis"
    _auto = False
    _description = "Driver Report View"

    employee_id = fields.Many2one('hr.employee', string="Name", required=True)
    date = fields.Datetime(string='Name')
    sale_order_id = fields.Many2one('sale.order', string="Sale Order")
    amount = fields.Float(string="Amount")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('in progress', 'In Progress'),
        ('assign', 'Assign'),
        ('cancel', 'Cancel')], string="Status",)
    def init(self):
        tools.drop_view_if_exists(self._cr, 'driver_analysis')
        self._cr.execute("""
        CREATE OR REPLACE VIEW driver_analysis AS(
        SELECT row_number() OVER () AS id,line.employee_id, line.sale_order_id,
        line.date,line.amount,line.state as state FROM(
            SELECT  so.employee_id, sol.sale_order_id, so.date, sol.amount, so.state
            FROM driver_registration_lines sol
            LEFT JOIN driver_registration so ON (so.id = sol.roaster_id)
            ) line
        )""")

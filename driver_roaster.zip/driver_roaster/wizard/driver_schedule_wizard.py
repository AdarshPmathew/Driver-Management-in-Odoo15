from odoo import api, fields, models
from calendar import monthrange
import datetime


class DriverWizard(models.TransientModel):
    _name = "driver.schedule.wizard"
    _description = "Driver Schedule Wizard"

    driver_ids = fields.Many2one('driver.registration', string="Driver")
    year_ss = fields.Char(string="Year")
    month_ss = fields.Selection([('1', 'January'), ('2', 'February'), ('3', 'March'), ('4', 'April'), ('5', 'May'),
                              ('6', 'June'), ('7', 'July'), ('8', 'August'), ('9', 'September'), ('10', 'October'),
                              ('11', 'November'),
                              ('12', 'December')], string='Month')

    def onchange_year_month(self):
        r = self.env['driver.schedule'].create({
            'driver_s': self.driver_ids.id,
            'month_s': self.month_ss,
            'year_s': self.year_ss,
        })
        r.onchange_year_month()




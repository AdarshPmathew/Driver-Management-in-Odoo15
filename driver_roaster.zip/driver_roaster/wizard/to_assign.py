from odoo import api, fields, models

class ToAssign(models.TransientModel):
    _name = "driver.assign"
    _description = "Driver Assign"

    driver_id = fields.Many2many('driver.registration', string="Drivers")

    def assign_button(self):
        for rec in self:
            rec.driver_id.state = 'assign'





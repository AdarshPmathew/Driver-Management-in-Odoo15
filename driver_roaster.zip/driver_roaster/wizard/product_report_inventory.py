from odoo import api, fields, models
from calendar import monthrange
import datetime

class ProdutReport(models.TransientModel):
    _name = "product.report.wizard"
    _description = "Product Report"


    product = fields.Many2many('product.product',string="Product")
    fdate = fields.Datetime(string='From Date')
    tdate = fields.Datetime(string='To Date')

    def action_product_report(self):
        # for dat in range(self.fdate, self.tdate):
        #     if rec.date in date:
            product_records = self.product

            # dt = self.env['stock.move.line'].search([('id', 'in', self.product.ids),('date', '>=', self.fdate), ('date', '<=', self.tdate)])
            # print(dt)
    # print(product_records)
            pdata = []
            for prod in product_records:
                product_name = prod.name
                dictpro = {
                    "name": product_name,
                }
                # print(product_name)
                # print(data)
                data = self.env['stock.move.line'].search([('product_id', '=', prod.id), ('date', '>=', self.fdate), ('date', '<=', self.tdate)])
                sin = 0
                sout = 0
                bal = 0
                sample = []
                for rec in data:
                    if (rec.picking_id.picking_type_id.code == "incoming"):
                        sin = rec.qty_done
                    if (rec.picking_id.picking_type_id.code == "outgoing"):
                        sout = rec.qty_done
                    bal = sin - sout
                    dictmove = {
                        "date": rec.date,
                        "reference": rec.reference,
                        "sale_p":  rec.product_id.lst_price,
                        "cost_p": rec.product_id.standard_price,
                        "cu_name": rec.picking_id.partner_id.name,
                        "stock_in": sin,
                        "stock_out": sout,
                        "balance": bal,
                    }
                    print("dict1=>", rec.picking_id.partner_id.name)
                    sample.append(dictmove)
                dictpro['values'] = sample
                pdata.append(dictpro)
            all_data = {
                    'datas': pdata
                }
            return self.env.ref('driver_roaster.action_product_report_first').report_action(self, data=all_data)











        # # data = self.env['product.template'].search([('product', '=', self.id)]).name
        # print(data)
        # # for rec in data:
        # #     if rec.name in data:
        # #         print(rec.name)
        # dic = []
        #
        # for rec in data:
        #     if self.product not in dic:
        #             pro_dict = {
        #                 'date': str(self.product.date),
        #                 'ref': int(self.product.lot_id),
        #                 'wh': str(self.product.reference),
        #                 # 'sale_p': str(self.product.list_price),
        #                 # 'lost_p': str(self.product.standard_price),
        #                 'cus_name': str(self.product.product_id.name),
        #                 # 'stock_in': str(self.product.default_code),
        #                 # 'stock_out': str(self.product.default_code),
        #                 'balance': str(self.product.qty_done),
        #             }
        #             dic.append(pro_dict)
        #             print("list", dic)
        #
        #             all_data = {
        #                 "product_data": dic,
        #             }
        #
        #             print("dictionary-->1", pro_dict)
        #             print("dictionary-->2", all_data)
        #             # print(self.product.name)
        #             # print(self.product.detailed_type)
        #             # print(self.product.invoice_policy)
        #             return self.env.ref('driver_roaster.action_product_report_first').report_action(self, data=all_data)
        #






from odoo import api, fields, models


class DriverReport(models.TransientModel):
    _name = "driver.report"
    _description = "Driver Report"

    names = fields.Many2one('hr.employee', string="Drivers",required=True)

    def print_pdf(self):
        driver_roaster_data = self.env['driver.registration'].sudo().search([('employee_id', '=', self.names.id)])
        print(driver_roaster_data)
        # print(driver_roaster_data)
        driver_list = []
        # lst = []
        sale_orders = ''

        for driver in driver_roaster_data:
            if driver.driver_registration_line_ids:
                for lines in driver.driver_registration_line_ids:
                    if lines.sale_order_id:
                        sale_orders = sale_orders + lines.sale_order_id.name + ','

        for record in driver_roaster_data:
            # lst.append(record.employee_id.name)
            # lst.append(record.department.name)
            # lst.append(record.state)
            dict = {
                'employee': record.employee_id.name,
                'date': record.date,
                'state': record.state,
                'sale_order': sale_orders,
            }
            driver_list.append(dict)
        print(driver_list)

        # dict.append(lst)

        data = {
            'roaster_data': driver_list,
        }
        # # print("Data -->>>", data)
        # print(data)

        return self.env.ref('driver_roaster.action_report_driver').report_action(self, data=data)




